import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Play, Pause, Square, RotateCcw } from "lucide-react";

export default function HomeworkCounter() {
  const [currentCount, setCurrentCount] = useState(0);
  const [totalQuestions, setTotalQuestions] = useState(0);
  const [currentScreen, setCurrentScreen] = useState<'setup' | 'counter' | 'completion'>('setup');
  const [inputValue, setInputValue] = useState('');
  
  // Timer state
  const [seconds, setSeconds] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  
  // Animation states
  const [isShaking, setIsShaking] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const [lastClickTime, setLastClickTime] = useState(0);
  
  // Mood and break states
  const [showMoodPopup, setShowMoodPopup] = useState(true);
  const [currentMood, setCurrentMood] = useState('');
  const [showBreakReminder, setShowBreakReminder] = useState(false);
  const [isOnBreak, setIsOnBreak] = useState(false);
  const [breakSeconds, setBreakSeconds] = useState(0);
  const [breakType, setBreakType] = useState('');
  const [lastBreakTime, setLastBreakTime] = useState(0);
  const [motivationalMessage, setMotivationalMessage] = useState('');
  const [showMotivationalBubble, setShowMotivationalBubble] = useState(false);
  const [usedBreakTypes, setUsedBreakTypes] = useState<string[]>([]);
  const [breakCooldownUntil, setBreakCooldownUntil] = useState(0);
  const breakTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Sound effects
  const playSound = (type: 'click' | 'complete' | 'success') => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      if (type === 'click') {
        oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(400, audioContext.currentTime + 0.1);
        gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
        oscillator.start();
        oscillator.stop(audioContext.currentTime + 0.1);
      } else if (type === 'complete') {
        oscillator.frequency.setValueAtTime(523.25, audioContext.currentTime); // C5
        oscillator.frequency.setValueAtTime(659.25, audioContext.currentTime + 0.1); // E5
        oscillator.frequency.setValueAtTime(783.99, audioContext.currentTime + 0.2); // G5
        gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
        oscillator.start();
        oscillator.stop(audioContext.currentTime + 0.3);
      } else if (type === 'success') {
        // Play celebration sound
        const frequencies = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
        frequencies.forEach((freq, index) => {
          setTimeout(() => {
            const osc = audioContext.createOscillator();
            const gain = audioContext.createGain();
            osc.connect(gain);
            gain.connect(audioContext.destination);
            osc.frequency.setValueAtTime(freq, audioContext.currentTime);
            gain.gain.setValueAtTime(0.1, audioContext.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);
            osc.start();
            osc.stop(audioContext.currentTime + 0.2);
          }, index * 100);
        });
      }
    } catch (error) {
      console.log('Audio not supported');
    }
  };

  // Mood and break functions
  const moods = [
    { emoji: '😊', label: 'Great', value: 'great' },
    { emoji: '😌', label: 'Good', value: 'good' },
    { emoji: '😐', label: 'Okay', value: 'okay' },
    { emoji: '😔', label: 'Tired', value: 'tired' },
    { emoji: '😤', label: 'Stressed', value: 'stressed' }
  ];

  const breakOptions = [
    { emoji: '📱', label: '5 min YouTube Shorts', duration: 300, value: 'youtube' },
    { emoji: '📸', label: '5 min Instagram', duration: 300, value: 'instagram' },
    { emoji: '🚶', label: '5 min Walk', duration: 300, value: 'walk' },
    { emoji: '☕', label: '5 min Coffee Break', duration: 300, value: 'coffee' }
  ];

  const getMotivationalMessage = (mood: string, timeWorked: number) => {
    const messages = {
      great: ['You\'re on fire! 🔥', 'Amazing energy! Keep it up!', 'You\'re crushing it!'],
      good: ['Steady progress! 💪', 'You\'re doing great!', 'Keep up the good work!'],
      okay: ['You\'re doing fine! 👍', 'Small steps count!', 'You\'ve got this!'],
      tired: ['Time for a break? 😴', 'You\'ve been working hard!', 'Rest if you need to!'],
      stressed: ['Take a deep breath 🧘', 'You\'re doing your best!', 'Break time might help!']
    };
    
    const moodMessages = messages[mood as keyof typeof messages] || messages.okay;
    return moodMessages[Math.floor(Math.random() * moodMessages.length)];
  };

  const handleMoodSelect = (mood: string) => {
    setCurrentMood(mood);
    setShowMoodPopup(false);
  };

  const startBreak = (breakType: string, duration: number) => {
    setIsOnBreak(true);
    setBreakType(breakType);
    setBreakSeconds(duration);
    setShowBreakReminder(false);
    setUsedBreakTypes(prev => [...prev, breakType]);
    setBreakCooldownUntil(seconds + 1800); // 30 minutes cooldown
    pauseTimer();
    
    breakTimerRef.current = setInterval(() => {
      setBreakSeconds(prev => {
        if (prev <= 1) {
          endBreak();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const endBreak = () => {
    setIsOnBreak(false);
    setBreakType('');
    setBreakSeconds(0);
    setLastBreakTime(seconds);
    if (breakTimerRef.current) {
      clearInterval(breakTimerRef.current);
      breakTimerRef.current = null;
    }
    playSound('complete');
  };

  const canTakeBreak = () => {
    return seconds >= lastBreakTime + 900; // 15 minutes since last break
  };

  const isInBreakCooldown = () => {
    return seconds < breakCooldownUntil;
  };

  // Timer functions
  const startTimer = () => {
    setIsTimerRunning(true);
    timerRef.current = setInterval(() => {
      setSeconds(prev => {
        const newSeconds = prev + 1;
        
        // Check for break reminder every 15 minutes (900 seconds)
        if (newSeconds - lastBreakTime >= 900 && !isOnBreak) {
          setShowBreakReminder(true);
        }
        
        // Show motivational messages every 5 minutes
        if (newSeconds % 300 === 0 && currentMood) {
          setMotivationalMessage(getMotivationalMessage(currentMood, newSeconds));
          setShowMotivationalBubble(true);
          setTimeout(() => setShowMotivationalBubble(false), 4000);
        }
        
        return newSeconds;
      });
    }, 1000);
  };

  const pauseTimer = () => {
    setIsTimerRunning(false);
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  const resetTimer = () => {
    setIsTimerRunning(false);
    setSeconds(0);
    setLastBreakTime(0);
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (breakTimerRef.current) {
      clearInterval(breakTimerRef.current);
      breakTimerRef.current = null;
    }
  };

  const formatTime = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  // Create ripple effect on click
  const createRipple = (event: React.MouseEvent<HTMLDivElement>) => {
    const counterArea = event.currentTarget;
    const ripple = document.createElement('span');
    ripple.classList.add('click-ripple');
    
    const rect = counterArea.getBoundingClientRect();
    const size = 60;
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;
    
    ripple.style.width = ripple.style.height = size + 'px';
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';
    
    counterArea.appendChild(ripple);
    
    setTimeout(() => {
      ripple.remove();
    }, 600);
  };

  // Handle counter area click
  const handleCounterClick = (event: React.MouseEvent<HTMLDivElement>) => {
    if (currentScreen === 'counter' && currentCount > 0) {
      const now = Date.now();
      
      // Prevent rapid clicking (debounce)
      if (now - lastClickTime < 200) return;
      setLastClickTime(now);
      
      createRipple(event);
      playSound('click');
      
      // Add shake animation for dramatic effect
      setIsShaking(true);
      setTimeout(() => setIsShaking(false), 200);
      
      const newCount = currentCount - 1;
      setCurrentCount(newCount);
      
      if (newCount === 0) {
        playSound('success');
        setShowConfetti(true);
        pauseTimer();
        setTimeout(() => {
          setCurrentScreen('completion');
          setShowConfetti(false);
        }, 1000);
      }
    }
  };

  // Handle start button click
  const handleStart = () => {
    const value = parseInt(inputValue);
    if (value && value > 0) {
      setTotalQuestions(value);
      setCurrentCount(value);
      setCurrentScreen('counter');
      // Auto-start timer when starting counter
      startTimer();
    }
  };

  // Handle reset
  const handleReset = () => {
    setCurrentCount(0);
    setTotalQuestions(0);
    setInputValue('');
    setCurrentScreen('setup');
    setShowMoodPopup(true);
    setCurrentMood('');
    setShowBreakReminder(false);
    setIsOnBreak(false);
    setBreakSeconds(0);
    setBreakType('');
    setMotivationalMessage('');
    setShowMotivationalBubble(false);
    setUsedBreakTypes([]);
    setBreakCooldownUntil(0);
    resetTimer();
  };

  // Handle new session
  const handleNewSession = () => {
    setCurrentCount(0);
    setTotalQuestions(0);
    setInputValue('');
    setCurrentScreen('setup');
    setShowMoodPopup(true);
    setCurrentMood('');
    setShowBreakReminder(false);
    setIsOnBreak(false);
    setBreakSeconds(0);
    setBreakType('');
    setMotivationalMessage('');
    setShowMotivationalBubble(false);
    setUsedBreakTypes([]);
    setBreakCooldownUntil(0);
    resetTimer();
  };

  // Calculate progress for the ring
  const progress = totalQuestions > 0 ? 1 - (currentCount / totalQuestions) : 0;
  const dashOffset = 314.16 * (1 - progress);

  // Timer cleanup effect
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  // Keyboard support
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (currentScreen === 'counter' && event.code === 'Space') {
        event.preventDefault();
        if (currentCount > 0) {
          const now = Date.now();
          
          // Prevent rapid clicking (debounce)
          if (now - lastClickTime < 200) return;
          setLastClickTime(now);
          
          playSound('click');
          setIsShaking(true);
          setTimeout(() => setIsShaking(false), 200);
          
          const newCount = currentCount - 1;
          setCurrentCount(newCount);
          
          if (newCount === 0) {
            playSound('success');
            setShowConfetti(true);
            pauseTimer();
            setTimeout(() => {
              setCurrentScreen('completion');
              setShowConfetti(false);
            }, 1000);
          }
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [currentScreen, currentCount, lastClickTime]);

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white">
      {/* Confetti animation */}
      {showConfetti && (
        <div className="fixed inset-0 pointer-events-none z-50">
          {[...Array(50)].map((_, i) => (
            <div
              key={i}
              className="confetti-piece"
              style={{
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                backgroundColor: ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FECA57', '#FF9FF3'][Math.floor(Math.random() * 6)]
              }}
            />
          ))}
        </div>
      )}

      {/* Mood Selection Popup */}
      {showMoodPopup && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <Card className="bg-gray-800 border-gray-700 text-white max-w-md w-full">
            <CardContent className="p-6">
              <div className="text-center space-y-6">
                <div className="text-4xl">💭</div>
                <h2 className="text-2xl font-bold text-white">How are you feeling today?</h2>
                <p className="text-gray-300">This helps us give you better encouragement!</p>
                
                <div className="grid grid-cols-2 gap-3">
                  {moods.map((mood) => (
                    <Button
                      key={mood.value}
                      onClick={() => handleMoodSelect(mood.value)}
                      className="h-16 bg-gray-700 hover:bg-gray-600 border-gray-600 text-white flex flex-col items-center justify-center space-y-1"
                    >
                      <div className="text-2xl">{mood.emoji}</div>
                      <div className="text-sm">{mood.label}</div>
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Break Reminder Popup */}
      {showBreakReminder && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <Card className="bg-gray-800 border-gray-700 text-white max-w-md w-full">
            <CardContent className="p-6">
              <div className="text-center space-y-6">
                <div className="text-4xl">⏰</div>
                <h2 className="text-2xl font-bold text-white">Time for a break!</h2>
                <p className="text-gray-300">You've been working for 15 minutes. Take a quick break?</p>
                
                <div className="space-y-3">
                  {breakOptions.map((option) => {
                    const isUsed = usedBreakTypes.includes(option.value);
                    return (
                      <Button
                        key={option.value}
                        onClick={() => !isUsed && startBreak(option.value, option.duration)}
                        disabled={isUsed}
                        className={`w-full h-14 flex items-center justify-center space-x-3 transition-all duration-300 ${
                          isUsed 
                            ? 'bg-gray-800 border-gray-700 text-gray-500 cursor-not-allowed opacity-50' 
                            : 'bg-gray-700 hover:bg-gray-600 border-gray-600 text-white'
                        }`}
                      >
                        <span className="text-2xl">{option.emoji}</span>
                        <span className={isUsed ? 'line-through' : ''}>{option.label}</span>
                        {isUsed && <span className="text-sm">✓ Used</span>}
                      </Button>
                    );
                  })}
                  
                  <Button
                    onClick={() => setShowBreakReminder(false)}
                    variant="outline"
                    className="w-full border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    Skip Break
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Break Timer Popup */}
      {isOnBreak && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <Card className="bg-gray-800 border-gray-700 text-white max-w-md w-full">
            <CardContent className="p-6">
              <div className="text-center space-y-6">
                <div className="text-4xl">🎯</div>
                <h2 className="text-2xl font-bold text-white">Break Time!</h2>
                <p className="text-gray-300 capitalize">{breakType} break in progress</p>
                
                <div className="text-6xl font-bold text-blue-400">
                  {Math.floor(breakSeconds / 60)}:{(breakSeconds % 60).toString().padStart(2, '0')}
                </div>
                
                <div className="space-y-3">
                  <Button
                    onClick={endBreak}
                    className="w-full bg-green-600 hover:bg-green-700 text-white"
                  >
                    End Break Early
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Motivational Speech Bubble */}
      {showMotivationalBubble && (
        <div className="fixed top-20 right-4 z-40 max-w-xs">
          <div className="bg-gray-800 border border-gray-700 rounded-2xl p-4 shadow-2xl speech-bubble">
            <div className="flex items-center space-x-2">
              <div className="text-2xl">💬</div>
              <p className="text-sm text-white font-medium">{motivationalMessage}</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Header */}
      <header className="px-6 py-4 bg-gray-800/90 backdrop-blur-xl border-b border-gray-700/50 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-2xl font-bold text-transparent bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text">
              📚 Homework Counter
            </h1>
            
            {/* Timer Display */}
            {currentScreen === 'counter' && (
              <Card className="px-4 py-2 bg-gradient-to-r from-green-900/40 to-blue-900/40 border-green-500/30">
                <CardContent className="p-0">
                  <div className="flex items-center space-x-2 text-sm">
                    <span className="text-green-400 font-semibold">⏱️ {formatTime(seconds)}</span>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
          
          <div className="flex items-center space-x-2">
            {/* Timer Controls */}
            {currentScreen === 'counter' && (
              <div className="flex items-center space-x-2">
                <Button
                  onClick={() => {
                    if (canTakeBreak() && !isInBreakCooldown()) {
                      setShowBreakReminder(true);
                    }
                  }}
                  disabled={!canTakeBreak() || isInBreakCooldown()}
                  size="sm"
                  className={`px-3 py-1 transition-all duration-300 ${
                    canTakeBreak() && !isInBreakCooldown()
                      ? 'bg-orange-600 hover:bg-orange-700 text-white shadow-lg animate-pulse'
                      : 'bg-orange-600/30 text-orange-200 cursor-not-allowed'
                  }`}
                >
                  Break
                </Button>
                <Button
                  onClick={isTimerRunning ? pauseTimer : startTimer}
                  size="sm"
                  className="bg-blue-600 hover:bg-blue-700 text-white h-8 w-8 p-0"
                >
                  {isTimerRunning ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </Button>
                <Button
                  onClick={resetTimer}
                  size="sm"
                  className="bg-gray-600 hover:bg-gray-700 text-white h-8 w-8 p-0"
                >
                  <RotateCcw className="h-4 w-4" />
                </Button>
              </div>
            )}
            
            <Button
              onClick={handleReset}
              className="px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-full font-medium text-sm hover:from-blue-600 hover:to-purple-600 transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              <Square className="h-4 w-4 mr-2" />
              Reset
            </Button>
          </div>
        </div>
      </header>

      {/* Main Counter Display */}
      <main 
        className="flex-1 flex flex-col items-center justify-center px-6 py-8 cursor-pointer relative"
        onClick={handleCounterClick}
      >
        {/* Setup Screen */}
        {currentScreen === 'setup' && !showMoodPopup && (
          <div className="text-center space-y-8 fade-in flex flex-col items-center justify-center min-h-[60vh]">
            <div className="space-y-4">
              <div className="text-6xl mb-4">📝</div>
              <h2 className="text-4xl font-bold text-transparent bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text mb-2">
                How many questions?
              </h2>
              <p className="text-gray-300 text-xl">Enter the total number of homework questions</p>
            </div>
            
            <div className="space-y-6 flex flex-col items-center">
              <div className="relative">
                <Input
                  type="number"
                  min="1"
                  max="999"
                  placeholder="Enter number"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  className="w-56 h-20 text-center text-3xl font-bold rounded-3xl border-4 border-gray-600 focus:border-blue-500 focus:outline-none transition-all duration-300 shadow-lg focus:shadow-2xl bg-gray-800 text-white placeholder-gray-400"
                  autoFocus
                />
              </div>
              
              <Button
                onClick={handleStart}
                disabled={!inputValue || parseInt(inputValue) <= 0}
                className="px-10 py-5 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-3xl font-bold text-xl hover:from-blue-600 hover:to-purple-600 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-2xl transform hover:scale-105 active:scale-95"
              >
                🚀 Start Counter
              </Button>
            </div>
          </div>
        )}

        {/* Counter Display Screen */}
        {currentScreen === 'counter' && (
          <div className="text-center space-y-8 w-full max-w-lg">
            <div className="space-y-6">
              <div className="relative">
                <Card className="bg-gradient-to-br from-gray-800 to-gray-900 shadow-2xl border-4 border-gray-600 p-8 rounded-3xl">
                  <CardContent className="p-0">
                    <p className="text-gray-300 text-xl mb-4 font-semibold">Questions remaining</p>
                    <div className={`relative transition-all duration-300 ${isShaking ? 'animate-pulse scale-105' : ''}`}>
                      <div className="number-display text-8xl md:text-[10rem] font-bold text-transparent bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text leading-none select-none drop-shadow-lg">
                        {currentCount}
                      </div>
                      {/* Glow effect */}
                      <div className="absolute inset-0 number-display text-8xl md:text-[10rem] font-bold text-blue-400 opacity-30 blur-sm leading-none select-none">
                        {currentCount}
                      </div>
                    </div>
                    <p className="text-gray-400 text-lg mt-4 font-medium">
                      ✨ Tap anywhere to mark one complete
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
            
            {/* Enhanced Progress Ring */}
            <div 
              className="relative w-40 h-40 mx-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-gray-700 to-gray-800 shadow-lg"></div>
              <svg className="w-40 h-40 transform -rotate-90 relative z-10" viewBox="0 0 120 120">
                <circle 
                  cx="60" 
                  cy="60" 
                  r="50" 
                  fill="none" 
                  stroke="#374151" 
                  strokeWidth="6"
                />
                <circle 
                  cx="60" 
                  cy="60" 
                  r="50" 
                  fill="none" 
                  stroke="url(#gradient)" 
                  strokeWidth="6" 
                  strokeLinecap="round"
                  strokeDasharray="314.16"
                  strokeDashoffset={dashOffset}
                  className="transition-all duration-500 ease-out drop-shadow-sm"
                />
                <defs>
                  <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#3B82F6" />
                    <stop offset="100%" stopColor="#8B5CF6" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-400">
                    {Math.round(progress * 100)}%
                  </div>
                  <div className="text-sm text-gray-400">Complete</div>
                </div>
              </div>
            </div>
            
            {/* Quick Break Button */}
            <div 
              className="flex flex-col items-center mt-4 space-y-2"
              onClick={(e) => e.stopPropagation()}
            >
              <Button
                onClick={(e) => {
                  e.stopPropagation();
                  if (canTakeBreak() && !isInBreakCooldown()) {
                    setShowBreakReminder(true);
                  }
                }}
                disabled={!canTakeBreak() || isInBreakCooldown()}
                className={`px-6 py-3 rounded-full font-semibold shadow-lg transition-all duration-300 ${
                  canTakeBreak() && !isInBreakCooldown()
                    ? 'bg-orange-600 hover:bg-orange-700 text-white hover:shadow-xl animate-pulse'
                    : 'bg-orange-600/30 text-orange-200 cursor-not-allowed shadow-sm'
                }`}
              >
                ☕ Take a Break
              </Button>
              
              {/* Break status indicator */}
              <div className="text-center text-xs text-gray-400">
                {isInBreakCooldown() ? (
                  <span>Break cooldown: {Math.floor((breakCooldownUntil - seconds) / 60)}m {(breakCooldownUntil - seconds) % 60}s</span>
                ) : canTakeBreak() ? (
                  <span className="text-orange-400 animate-pulse">Break available!</span>
                ) : (
                  <span>Next break in: {Math.floor((900 - (seconds - lastBreakTime)) / 60)}m {(900 - (seconds - lastBreakTime)) % 60}s</span>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Completion Screen */}
        {currentScreen === 'completion' && (
          <div className="text-center space-y-8 bounce-in">
            <div className="space-y-6">
              <div className="text-8xl animate-bounce">🎉</div>
              <Card className="bg-gradient-to-br from-gray-800 to-gray-900 shadow-2xl border-4 border-green-500/30 p-8 rounded-3xl max-w-md mx-auto">
                <CardContent className="p-0">
                  <h2 className="text-5xl font-bold text-transparent bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text mb-4">
                    All Done!
                  </h2>
                  <p className="text-gray-300 text-xl mb-4">
                    Great job completing your homework!
                  </p>
                  <div className="bg-gray-700/50 rounded-2xl p-4 mb-4">
                    <p className="text-lg font-semibold text-green-400">
                      📊 Session Stats
                    </p>
                    <p className="text-sm text-gray-300">
                      {totalQuestions} questions completed in {formatTime(seconds)}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <Button
              onClick={handleNewSession}
              className="px-10 py-5 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-3xl font-bold text-xl hover:from-green-600 hover:to-blue-600 transition-all duration-300 shadow-lg hover:shadow-2xl transform hover:scale-105 active:scale-95"
            >
              🚀 Start New Session
            </Button>
          </div>
        )}
      </main>

      {/* Enhanced Footer */}
      <footer className="px-6 py-4 bg-gray-800/90 backdrop-blur-xl border-t border-gray-700/50 shadow-lg">
        <div className="text-center">
          <p className="text-gray-300 text-sm font-medium">
            Stay focused and keep going! You've got this! 💪
          </p>
        </div>
      </footer>
    </div>
  );
}
