# Overview

This is a full-stack React application with an Express backend, built for tracking homework progress. The application features a homework counter with timer functionality, mood tracking, break reminders, and motivational features. It uses a modern tech stack with TypeScript, React, Express, and PostgreSQL with Drizzle ORM.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **UI Library**: Radix UI components with shadcn/ui styling
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **State Management**: React hooks and TanStack Query for server state
- **Routing**: Wouter for client-side routing
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **Database**: PostgreSQL with Neon serverless driver
- **ORM**: Drizzle ORM for type-safe database operations
- **Session Management**: Connect-pg-simple for PostgreSQL session storage
- **Development**: tsx for TypeScript execution

## Key Components

### Frontend Components
1. **HomeworkCounter**: Main application component with timer, counter, and break functionality
2. **UI Components**: Complete set of Radix UI components (buttons, cards, dialogs, etc.)
3. **Routing**: Simple router with homepage and 404 handling
4. **State Management**: React Query for API calls and local state for UI

### Backend Components
1. **Express Server**: RESTful API server with middleware for logging and error handling
2. **Database Layer**: Drizzle ORM with PostgreSQL connection
3. **Storage Interface**: Abstracted storage layer with in-memory implementation
4. **Vite Integration**: Development server with HMR support

### Database Schema
- **Users Table**: Basic user authentication with username/password
- **Schema Validation**: Zod schemas for type safety and validation
- **Migration System**: Drizzle migrations for database schema changes

## Data Flow

1. **Client Requests**: React components make API calls through TanStack Query
2. **API Routes**: Express routes handle HTTP requests and responses
3. **Business Logic**: Storage interface abstracts database operations
4. **Database Operations**: Drizzle ORM executes type-safe SQL queries
5. **Response Handling**: JSON responses with proper error handling

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection for Neon database
- **drizzle-orm**: Type-safe ORM for database operations
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Headless UI components
- **tailwindcss**: Utility-first CSS framework
- **wouter**: Lightweight React router

### Development Dependencies
- **vite**: Fast build tool and development server
- **typescript**: Static type checking
- **tsx**: TypeScript execution for Node.js
- **@replit/vite-plugin-***: Replit-specific development tools

## Deployment Strategy

### Build Process
1. **Frontend Build**: Vite builds React application to `dist/public`
2. **Backend Build**: esbuild bundles Express server to `dist/index.js`
3. **Static Assets**: Frontend assets served from Express in production

### Environment Configuration
- **Development**: tsx runs server with Vite middleware for HMR
- **Production**: Node.js serves bundled application with static file serving
- **Database**: PostgreSQL connection via DATABASE_URL environment variable

### Scripts
- `dev`: Development server with hot reloading
- `build`: Production build for both frontend and backend
- `start`: Production server execution
- `db:push`: Database schema deployment

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- July 05, 2025. Initial setup